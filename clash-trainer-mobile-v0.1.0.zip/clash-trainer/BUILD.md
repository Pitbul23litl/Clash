# Release checklist

1. `npm run sync`
2. `npm run validate-data`
3. `npm run sync-assets`
4. `npm run validate`
5. `npm test`
6. Serve the folder over HTTPS and install the PWA to the phone's home screen.

`sync` is the authoritative data import step. The app first tries local `data/*.json`, then remote RoyaleAPI data if the local set is not present. `sync-assets` downloads card PNGs to `assets/cards/`; the runtime falls back to the public asset URL for a missing local file.

The battle engine is intentionally a training simulation. It is not claimed to reproduce Supercell's private server simulation frame-for-frame.
