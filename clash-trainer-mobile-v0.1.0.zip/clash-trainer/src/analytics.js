const KEY='clash-trainer-analytics-v1';
export function loadAnalytics(){try{return JSON.parse(localStorage.getItem(KEY))||emptyAnalytics()}catch{return emptyAnalytics()}}
export function emptyAnalytics(){return {games:0,wins:0,losses:0,card:{},mistakes:{},skills:{},opponents:{}}}
export function recordBattle(a,{won,actions=[]}){
  a.games++; won?a.wins++:a.losses++;
  for(const x of actions.filter(v=>v.who==='player')){
    a.card[x.card] ||= {played:0,elixir:0,successful:0};
    a.card[x.card].played++; a.card[x.card].elixir += Number(x.elixir||0);
  }
  for(const m of arguments[2]?.mistakes||[]) a.mistakes[m.type]=(a.mistakes[m.type]||0)+1;
  localStorage.setItem(KEY,JSON.stringify(a));
}
export function cardPerformance(analytics,key){const x=analytics.card[key];if(!x)return 0;return Math.log1p(x.played)*0.45-(x.elixir/(x.played||1))*0.02-(analytics.mistakes.predictability||0)*0.01}
export function recommendDecks(cards,analytics,count=3){
  const scored=cards.map(c=>({c,score:cardPerformance(analytics,c.key)})).sort((a,b)=>b.score-a.score);
  const families=[['control','win-condition','spell','building'],['cycle','win-condition','spell','cycle'],['beatdown','win-condition','tank','support'],['bait','win-condition','swarm','spell']];
  return families.slice(0,count).map((family,i)=>{
    const selected=[]; const pickRole=(role)=>scored.find(x=>!selected.some(s=>s.key===x.c.key) && x.c.type && (role==='spell'?x.c.type==='Spell':x.c.type!=='Spell'));
    const wc=scored.find(x=>/(hog-rider|royal-giant|giant|golem|balloon|miner|wall-breakers|royal-hogs|battle-ram|goblin-giant|minion-giant)/i.test(x.c.key)); if(wc)selected.push(wc.c);
    const sp=scored.find(x=>x.c.type==='Spell'&&!selected.some(s=>s.key===x.c.key)); if(sp)selected.push(sp.c);
    while(selected.length<8){const role=family[selected.length%family.length];const v=pickRole(role)||scored.find(x=>!selected.some(s=>s.key===x.c.key));if(!v)break;selected.push(v.c)}
    return {name:familyName(family,i),cards:selected.slice(0,8),reason:reasonForDeck(family,selected,analytics)};
  });
}
function familyName(f,i){return ['Контроль + давление','Быстрый цикл','Тяжёлый push','Bait/pressure'][i]}
function reasonForDeck(f,selected,a){const avg=selected.reduce((s,c)=>s+c.elixir,0)/(selected.length||1);return `Средняя стоимость ${avg.toFixed(1)}. Состав собран вокруг ${selected[0]?.name||'win condition'} и твоей истории использования; по мере матчей рекомендации будут перестраиваться.`}
