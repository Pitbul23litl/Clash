export const PHASES = { SINGLE:'single', DOUBLE:'double', OVERTIME:'overtime' };
export const MAX_ELIXIR = 10;

export function phaseForTime(seconds) {
  if (seconds >= 120) return PHASES.DOUBLE;
  return PHASES.SINGLE;
}

export function elixirRate(seconds) {
  return seconds >= 120 ? 2 : 1;
}

export function tickElixir(elixir, dt, seconds) {
  return Math.min(MAX_ELIXIR, elixir + dt * elixirRate(seconds) / 2.8);
}

export function averageElixir(deck) {
  if (!deck.length) return 0;
  return deck.reduce((s,c) => s + Number(c.elixir||0), 0) / deck.length;
}

export function classifyCard(card) {
  const n = card.name.toLowerCase();
  const onlyBuildings = card.stats?.targetOnlyBuildings;
  if (onlyBuildings || /(hog rider|giant|golem|balloon|royal giant|lava hound|battle ram|wall breakers|royal hogs|goblin giant|goblin drill|minion giant)/i.test(n)) return ['win-condition'];
  if (card.type === 'Spell') return ['spell'];
  if (/(musketeer|wizard|archers|princess|dart goblin|firecracker|executioner|witch|magic archer|flying machine|hunter)/i.test(n)) return ['ranged'];
  if (/(skeletons|goblins|bats|minions|guards|spear goblins|barbarians|goblin gang)/i.test(n)) return ['swarm'];
  if (/(cannon|tesla|bomb tower|inferno tower|tombstone|goblin cage|building)/i.test(n)) return ['building'];
  if (/(ice spirit|fire spirit|electro spirit|heal spirit)/i.test(n)) return ['cycle'];
  if (/(pekka|mini pekka|valkyrie|knight|dark prince|mega knight|bandit|lumberjack|monk|golden knight)/i.test(n)) return ['melee'];
  return ['support'];
}

export function counterScore(defender, attacker) {
  const a = attacker.name.toLowerCase(), d = defender.name.toLowerCase();
  let score = 0;
  if (/(hog rider|battle ram|giant|golem|balloon|royal giant|goblin giant)/i.test(a) && /(cannon|tesla|bomb tower|inferno tower|goblin cage|tombstone|building)/i.test(d)) score += 3;
  if (/(minions|bats|skeleton army|goblin gang|goblins)/i.test(a) && /(wizard|valkyrie|bowler|baby dragon|fireball|arrows|zap|bomber)/i.test(d)) score += 3;
  if (/(pekka|mega knight|mini pekka|knight)/i.test(a) && /(skeletons|goblins|ice spirit|bats)/i.test(d)) score += 1;
  if (/(musketeer|wizard|princess|firecracker)/i.test(a) && /(miner|knight|bandit|mini pekka|golden knight)/i.test(d)) score += 2;
  return score;
}

export function makeInitialState(playerDeck, botDeck) {
  const rotate = d => d.slice(0,4);
  return {
    time:0, phase:PHASES.SINGLE, status:'running', winner:null,
    players:{
      player:{elixir:5, deck:playerDeck, hand:rotate(playerDeck), next:playerDeck.slice(4), towerHp: {'L':3052,'R':3052,'K':4526}, kingActive:false, units:[]},
      bot:{elixir:5, deck:botDeck, hand:rotate(botDeck), next:botDeck.slice(4), towerHp: {'L':3052,'R':3052,'K':4526}, kingActive:false, units:[]}
    }, events:[], mistakes:[], actions:[]
  };
}

export function advanceHand(side) {
  const [played,...rest] = side.hand;
  const [newCard,...remaining] = side.next;
  side.hand = [...rest, newCard].filter(Boolean);
  side.next = [...remaining, played];
}

export function canPlay(side, cardKey) {
  return !!side.hand.find(c=>c.key===cardKey) && side.elixir >= Number(side.hand.find(c=>c.key===cardKey).elixir||0);
}

export function playCard(state, who, cardKey, position) {
  const side = state.players[who];
  const card = side.hand.find(c=>c.key===cardKey);
  if (!card) return {ok:false,reason:'not-in-hand'};
  const cost = Number(card.elixir||0);
  if (side.elixir < cost) return {ok:false,reason:'insufficient-elixir'};
  side.elixir -= cost;
  advanceHand(side);
  const unit = {id:`${who}-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,owner:who,key:card.key,name:card.name,hp:card.stats?.hp||1000,maxHp:card.stats?.hp||1000,x:position?.x??0.5,y:position?.y??(who==='player'?0.75:0.25),card,spawnedAt:state.time};
  side.units.push(unit);
  state.actions.push({time:state.time,who,card:card.key,position});
  state.events.push({time:state.time,type:'deploy',who,card:card.key});
  return {ok:true,unit};
}

export function estimateMistakes(state) {
  const actions = state.actions.filter(a=>a.who==='player');
  const mistakes=[];
  const player=state.players.player;
  if (!actions.length) mistakes.push({type:'passivity',severity:'medium',text:'В этом бою почти не было игровых решений — тренажёр не получил достаточно данных.'});
  const avgSpent=actions.length ? actions.reduce((s,a)=>s+Number(state.players.player.deck.find(c=>c.key===a.card)?.elixir||0),0)/actions.length:0;
  if (player.elixir > 8.5 && state.time > 20) mistakes.push({type:'elixir-float',severity:'medium',text:'Ты часто держал полный/почти полный эликсир и не конвертировал ресурс в давление или цикл.'});
  const same = actions.reduce((m,a)=>(m[a.card]=(m[a.card]||0)+1,m),{});
  const overuse=Object.entries(same).find(([,n])=>n>=4);
  if (overuse) mistakes.push({type:'predictability',severity:'medium',text:`Карта ${overuse[0]} использовалась ${overuse[1]} раз — это делает цикл предсказуемым.`});
  return mistakes;
}

export function chooseBotDeck(cards, playerDeck, seed=7) {
  const rng=mulberry32(seed);
  const pool=cards.filter(c=>c.type && c.elixir!==undefined);
  const roles={};
  for(const c of pool) roles[c.key]=classifyCard(c)[0];
  const must=['win-condition','spell','building','support','melee','swarm','ranged'];
  const deck=[];
  const shuffled=[...pool].sort(()=>rng()-0.5);
  for(const role of must){
    const candidate=shuffled.find(c=>roles[c.key]===role && !deck.some(x=>x.key===c.key));
    if(candidate) deck.push(candidate);
  }
  const anti=shuffled
    .filter(c=>!deck.some(x=>x.key===c.key))
    .map(c=>({c,score:playerDeck.reduce((s,p)=>s+counterScore(c,p),0)+rng()}))
    .sort((a,b)=>b.score-a.score);
  for(const item of anti) if(deck.length<8) deck.push(item.c);
  return deck.slice(0,8);
}

function mulberry32(a){return function(){let t=a+=0x6D2B79F5;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296}}

export function botAction(state) {
  const bot=state.players.bot;
  const candidates=bot.hand.filter(c=>bot.elixir >= Number(c.elixir||0));
  if(!candidates.length) return null;
  const playerUnits=state.players.player.units.filter(u=>u.hp>0);
  let scored=candidates.map(card=>{
    const pressure=/(win|condition)/.test(classifyCard(card).join())?2:0;
    const counter=playerUnits.reduce((s,u)=>s+counterScore(card,u.card),0);
    const cycle=card.elixir<=2?1:0;
    return {card,score:pressure+counter+cycle+(Math.random()*0.75)};
  }).sort((a,b)=>b.score-a.score);
  const pick=scored[0].card;
  return playCard(state,'bot',pick.key,{x:pick.type==='Spell'?0.5:0.45,y:0.28});
}

export function stepState(state, dt=0.25) {
  if(state.status!=='running') return state;
  state.time += dt;
  state.phase=phaseForTime(state.time);
  for(const side of Object.values(state.players)) side.elixir=tickElixir(side.elixir,dt,state.time);
  // lightweight deterministic combat model for training, not a replacement for Supercell's game server.
  for(const owner of ['player','bot']){
    const enemy=owner==='player'?'bot':'player';
    for(const u of state.players[owner].units){
      if(u.hp<=0) continue;
      const targets=state.players[enemy].units.filter(t=>t.hp>0);
      if(targets.length){
        const t=targets[0];
        const dps=u.card.stats?.dps||((u.card.stats?.damage||0)/Math.max(1,(u.card.stats?.hitSpeedMs||1200)/1000));
        t.hp-=dps*dt;
      }else{
        const targetTower=state.players[enemy].towerHp.R;
        state.players[enemy].towerHp.R=Math.max(0,targetTower-(u.card.stats?.dps||50)*dt*0.18);
      }
    }
  }
  for(const owner of ['player','bot']) state.players[owner].units=state.players[owner].units.filter(u=>u.hp>0);
  if(state.players.player.towerHp.R<=0 || state.players.player.towerHp.K<=0){state.status='finished';state.winner='bot';}
  if(state.players.bot.towerHp.R<=0 || state.players.bot.towerHp.K<=0){state.status='finished';state.winner='player';}
  if(state.time>=300 && state.status==='running'){state.status='finished';state.winner=state.players.player.towerHp.R>=state.players.bot.towerHp.R?'player':'bot';}
  return state;
}
