import { loadDatabase, assetUrl } from './data.js';
import { makeInitialState, playCard, stepState, chooseBotDeck, estimateMistakes, averageElixir } from './engine.js';
import { SCENARIOS } from './scenarios.js';
import { loadAnalytics, recommendDecks } from './analytics.js';

const root=document.querySelector('#app');
const state={db:null, level:11, online:false, screen:'home', deck:[], battle:null, stats:{games:0,wins:0,cardUse:{},mistakes:{}}, analytics:loadAnalytics(), selectedCard:null};

const demoDeckKeys=['hog-rider','musketeer','valkyrie','cannon','fireball','skeletons','ice-spirit','archers'];
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function cardByKey(k){return state.db?.cards.find(c=>c.key===k);}
function cardImage(card, variant='base'){return card?.localImage || card?.image || assetUrl(card?.key||'card-legendary-unknown',variant);}
function render(){
  if(state.screen==='home') return renderHome();
  if(state.screen==='deck') return renderDeck();
  if(state.screen==='cards') return renderCards();
  if(state.screen==='battle') return renderBattle();
  if(state.screen==='report') return renderReport();
  if(state.screen==='scenarios') return renderScenarios();
}
function nav(){return `<nav class="nav"><button data-screen="home">Главная</button><button data-screen="deck">Колода</button><button data-screen="cards">Карты</button><button data-screen="scenarios">Сценарии</button><button data-screen="battle">Бой</button></nav>`}
function shell(body){return `<div class="shell"><header><div><div class="eyebrow">CLASH TRAINER</div><h1>Тренируй решения, а не удачу</h1></div><span class="pill">${state.online?'LIVE DATA':'OFFLINE CACHE'}</span></header>${body}${nav()}</div>`}
function cardTile(c,small=false){return `<div class="card ${small?'small':''}" data-card="${esc(c.key)}"><img src="${esc(cardImage(c))}" alt="${esc(c.name)}" onerror="this.src='${assetUrl('card-legendary-unknown')}'"><div class="card-name">${esc(c.name)}</div><span class="elixir">${c.elixir}</span></div>`}
function renderHome(){
  const total=state.db?.cards.length||0;
  const recs=state.db?recommendDecks(state.db.cards,state.analytics,2):[];
  return shell(`<main class="content"><section class="hero"><div><h2>Тренажёр тактического мышления</h2><p>Ты играешь против адаптивного бота. После боя анализируются расход эликсира, повторяемость, пропуски и слабые места. Колода бота строится под твой набор карт и меняется от боя к бою.</p><div class="actions"><button class="primary" id="start">Начать бой</button><button id="open-cards">Открыть базу карт</button></div></div><div class="statbox"><b>${total}</b><span>карт загружено</span><b>${state.stats.games}</b><span>боёв</span><b>${state.stats.games?Math.round(state.stats.wins/state.stats.games*100):0}%</b><span>побед</span></div></section><section class="panel"><h3>Персональные рекомендации</h3><div class="rec-grid">${recs.map(r=>`<div class="recommendation"><b>${esc(r.name)}</b><span>${esc(r.reason)}</span><div class="mini-deck">${r.cards.map(c=>`<img src="${cardImage(c)}" alt="${esc(c.name)}">`).join('')}</div></div>`).join('')}</div></section><section class="panel"><h3>Что тренируется</h3><div class="chips"><span>Эликсир</span><span>Цикл</span><span>Placement</span><span>Prediction</span><span>Защита</span><span>Спеллы</span><span>Темп</span><span>Ошибки</span></div></section><section class="panel"><h3>Источник данных</h3><p>Карточная база и технические статы синхронизируются из RoyaleAPI static data. Визуальные ассеты подтягиваются из публичного набора cr-api-assets. Последние изменения баланса применяются через версионирование данных.</p><small>Уровень симуляции: ${state.level}. Для публикации используй scripts/sync-data.mjs и scripts/validate-assets.mjs.</small></section></main>`)}
function renderDeck(){
  const cards=state.deck.length?state.deck:demoDeckKeys.map(cardByKey).filter(Boolean);
  state.deck=cards;
  return shell(`<main class="content"><section class="panel"><div class="row between"><div><h2>Твоя колода</h2><p>Средняя стоимость: <b>${averageElixir(cards).toFixed(2)}</b></p></div><button id="randomize">Собрать колоду</button></div><div class="deck-grid">${cards.map(c=>cardTile(c,true)).join('')}</div></section><section class="panel"><h3>Настройки тренировки</h3><label>Уровень карт <input id="level" type="range" min="1" max="16" value="${state.level}"></label><div class="range-row"><span>1</span><b id="level-val">${state.level}</b><span>16</span></div><button class="primary" id="save-settings">Сохранить</button></section></main>`)}
function renderCards(){
  const cards=state.db?.cards||[];
  return shell(`<main class="content"><section class="panel"><div class="row"><input id="search" placeholder="Поиск карты…"><select id="filter"><option value="all">Все</option><option>Troop</option><option>Building</option><option>Spell</option></select></div><p class="muted">Найдено: <b id="count">${cards.length}</b></p><div class="cards-grid" id="cards-grid">${cards.map(c=>cardTile(c)).join('')}</div></section></main>`)}
function renderBattle(){
  const b=state.battle; if(!b) return shell(`<main class="content"><button class="primary" id="start">Начать бой</button></main>`);
  const me=b.players.player, bot=b.players.bot;
  const time=Math.max(0,300-b.time), mins=String(Math.floor(time/60)).padStart(1,'0'), secs=String(Math.floor(time%60)).padStart(2,'0');
  return shell(`<main class="battle-wrap"><section class="battle-ui"><div class="topbar"><span>Враг • скрытая колода</span><b>${mins}:${secs}</b><span>Эликсир ${me.elixir.toFixed(1)}</span></div><div class="arena ${state.selectedCard?'placement-mode':''}" id="arena" style="background-image:url('${SOURCESArena()}')"><div class="river"></div><div class="tower left"><span>${Math.round(me.towerHp.L)}</span></div><div class="tower right"><span>${Math.round(me.towerHp.R)}</span></div><div class="king"><span>${Math.round(me.towerHp.K)}</span></div>${me.units.map(renderUnit).join('')}${bot.units.map(renderUnit).join('')}</div><div class="hand">${me.hand.map(c=>`<button class="hand-card ${state.selectedCard===c.key?'selected':''}" data-select="${c.key}" ${me.elixir<c.elixir?'disabled':''}><img src="${cardImage(c)}" alt=""><span>${esc(c.name)}</span><b>${c.elixir}</b></button>`).join('')}</div><div class="battle-actions"><button id="pause">Пауза</button><button id="finish">Завершить бой</button></div></section></main>`)}
function renderUnit(u){const x=Math.round(u.x*100), y=Math.round(u.y*100); return `<div class="unit ${u.owner}" style="left:${x}%;top:${y}%"><img src="${cardImage(u.card)}" alt=""><span>${Math.max(0,Math.round(u.hp))}</span></div>`}
function SOURCESArena(){return 'https://raw.githubusercontent.com/RoyaleAPI/cr-api-assets/master/arenas/arena23.png'}
function renderScenarios(){return shell(`<main class="content"><section class="panel"><div class="row between"><div><h2>Лаборатория сценариев</h2><p>40 микротренировок по отдельным навыкам.</p></div><span class="pill">${SCENARIOS.length} сценария</span></div><div class="scenario-grid">${SCENARIOS.map((s,i)=>`<button class="scenario" data-scenario="${s.id}"><b>${String(i+1).padStart(2,'0')} · ${esc(s.name)}</b><span>${esc(s.skill)}</span><p>${esc(s.prompt)}</p></button>`).join('')}</div></section></main>`)}
function renderReport(){const m=state.battle?estimateMistakes(state.battle):[];return shell(`<main class="content"><section class="panel"><h2>Разбор боя</h2><div class="report-head"><b>${state.stats.games}</b><span>боёв</span><b>${state.stats.wins}</b><span>побед</span></div><h3>Что заметил тренажёр</h3>${m.length?m.map(x=>`<div class="mistake ${x.severity}"><b>${esc(x.type)}</b><p>${esc(x.text)}</p></div>`).join(''):'<p>Явных повторяющихся ошибок в этом бою не нашлось. Нужна ещё статистика.</p>'}<h3>Следующая тренировка</h3><div class="training"><p>1. Сыграй 3 боя с той же колодой.</p><p>2. Не допускай полного эликсира дольше 3 секунд без причины.</p><p>3. Перед каждым защитным действием называй вслух угрозу и стоимость ответа.</p></div><button class="primary" id="start">Следующий бой</button></section></main>`)}

function startBattle(){
  const playerDeck=state.deck.length?state.deck:(demoDeckKeys.map(cardByKey).filter(Boolean));
  const botDeck=chooseBotDeck(state.db.cards,playerDeck,Date.now()%100000);
  state.battle=makeInitialState(playerDeck,botDeck); state.screen='battle'; state.selectedCard=null; render();
  const timer=setInterval(()=>{if(state.screen!=='battle'){clearInterval(timer);return;} const result=stepState(state.battle,0.25); if(Math.floor(result.time*4)%8===0 && Math.random()<0.45) botActionSafe(); render(); if(result.status==='finished'){clearInterval(timer); finishBattle();}},250);
  window.currentTimer=timer;
}
function botActionSafe(){try{import('./engine.js').then(({botAction})=>botAction(state.battle))}catch{}}
function finishBattle(){if(window.currentTimer)clearInterval(window.currentTimer); const won=state.battle?.winner==='player'; state.stats.games++; if(won)state.stats.wins++; const m=estimateMistakes(state.battle); for(const x of m)state.stats.mistakes[x.type]=(state.stats.mistakes[x.type]||0)+1; for(const a of state.battle?.actions||[])if(a.who==='player'){state.analytics.card[a.card] ||= {played:0,elixir:0};state.analytics.card[a.card].played++;state.analytics.card[a.card].elixir += Number(cardByKey(a.card)?.elixir||0)} state.analytics.games=state.stats.games;state.analytics.wins=state.stats.wins;state.analytics.losses=state.stats.games-state.stats.wins;state.analytics.mistakes=state.stats.mistakes;localStorage.setItem('clash-trainer-analytics-v1',JSON.stringify(state.analytics));state.screen='report'; render(); saveStats();}
function saveStats(){localStorage.setItem('clash-trainer-stats',JSON.stringify(state.stats));}
function loadStats(){try{const s=JSON.parse(localStorage.getItem('clash-trainer-stats')); if(s)Object.assign(state.stats,s)}catch{}}

root.addEventListener('click',e=>{
  const screen=e.target.closest('[data-screen]')?.dataset.screen; if(screen){state.screen=screen; render(); return;}
  if(e.target.id==='start'||e.target.id==='open-cards'){state.screen=e.target.id==='open-cards'?'cards':'battle'; if(state.screen==='battle')startBattle(); else render();}
  if(e.target.id==='randomize'){const pool=[...state.db.cards]; state.deck=[]; while(state.deck.length<8 && pool.length){const i=Math.floor(Math.random()*pool.length); state.deck.push(pool.splice(i,1)[0]);} render();}
  if(e.target.id==='save-settings'){const val=Number(document.querySelector('#level')?.value||11);state.level=val;loadDatabase({level:val}).then(({db,online})=>{state.db=db;state.online=online;render();});}
  if(e.target.id==='finish'){finishBattle();}
  if(e.target.id==='pause'){e.target.textContent=e.target.textContent==='Пауза'?'Продолжить':'Пауза'; window.currentTimer? (e.target.textContent==='Продолжить'?clearInterval(window.currentTimer):startBattle()):null;}
  const select=e.target.closest('[data-select]')?.dataset.select; if(select && state.battle){state.selectedCard=select; render(); return;}
  if(e.target.closest('#arena') && state.battle && state.selectedCard){const rect=document.querySelector('#arena').getBoundingClientRect(); const x=Math.max(0,Math.min(1,(e.clientX-rect.left)/rect.width)); const y=Math.max(0,Math.min(1,(e.clientY-rect.top)/rect.height)); const r=playCard(state.battle,'player',state.selectedCard,{x,y}); if(r.ok)state.selectedCard=null; render();}
});

document.addEventListener('click',e=>{const sc=e.target.closest('[data-scenario]')?.dataset.scenario;if(sc){const item=SCENARIOS.find(x=>x.id===sc);alert(`${item.name}\n\n${item.prompt}\n\nНавык: ${item.skill}`)}});

document.addEventListener('input',e=>{if(e.target.id==='search'){const q=e.target.value.toLowerCase();document.querySelectorAll('#cards-grid .card').forEach(el=>el.style.display=el.innerText.toLowerCase().includes(q)?'':'none');} if(e.target.id==='level')document.querySelector('#level-val').textContent=e.target.value;});

loadStats();
loadDatabase({level:11}).then(({db,online})=>{state.db=db;state.online=online;state.deck=demoDeckKeys.map(cardByKey).filter(Boolean);render();});
if('serviceWorker' in navigator) navigator.serviceWorker.register('service-worker.js').catch(()=>{});
