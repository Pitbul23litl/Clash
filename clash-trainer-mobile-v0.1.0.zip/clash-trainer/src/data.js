export const SOURCES = {
  cards: 'https://raw.githubusercontent.com/RoyaleAPI/cr-api-data/master/docs/json/cards.json',
  stats: [
    'https://raw.githubusercontent.com/RoyaleAPI/cr-api-data/master/docs/json/cards_stats_troop.json',
    'https://raw.githubusercontent.com/RoyaleAPI/cr-api-data/master/docs/json/cards_stats_building.json',
    'https://raw.githubusercontent.com/RoyaleAPI/cr-api-data/master/docs/json/cards_stats_spell.json',
    'https://raw.githubusercontent.com/RoyaleAPI/cr-api-data/master/docs/json/cards_stats_characters.json',
    'https://raw.githubusercontent.com/RoyaleAPI/cr-api-data/master/docs/json/cards_stats_projectile.json',
    'https://raw.githubusercontent.com/RoyaleAPI/cr-api-data/master/docs/json/cards_evo.json'
  ],
  assets: 'https://raw.githubusercontent.com/RoyaleAPI/cr-api-assets/master/cards/',
  arenas: 'https://raw.githubusercontent.com/RoyaleAPI/cr-api-assets/master/arenas/'
};

export const FALLBACK_CARDS = [
  {key:'knight',name:'Knight',elixir:3,type:'Troop',rarity:'Common',arena:0,description:'A tough melee fighter.',id:26000000},
  {key:'archers',name:'Archers',elixir:3,type:'Troop',rarity:'Common',arena:0,description:'A pair of ranged attackers.',id:26000001},
  {key:'goblins',name:'Goblins',elixir:2,type:'Troop',rarity:'Common',arena:1,description:'Fast melee attackers.',id:26000002},
  {key:'giant',name:'Giant',elixir:5,type:'Troop',rarity:'Rare',arena:0,description:'Durable troop that targets buildings.',id:26000003},
  {key:'pekka',name:'P.E.K.K.A',elixir:7,type:'Troop',rarity:'Epic',arena:6,description:'Heavy melee fighter.',id:26000004},
  {key:'minions',name:'Minions',elixir:3,type:'Troop',rarity:'Common',arena:0,description:'Fast flying attackers.',id:26000005},
  {key:'balloon',name:'Balloon',elixir:5,type:'Troop',rarity:'Epic',arena:7,description:'Flying building-targeting bomber.',id:26000006},
  {key:'witch',name:'Witch',elixir:5,type:'Troop',rarity:'Epic',arena:6,description:'Summoner with area damage.',id:26000007},
  {key:'barbarians',name:'Barbarians',elixir:5,type:'Troop',rarity:'Common',arena:3,description:'Melee group.',id:26000008},
  {key:'golem',name:'Golem',elixir:8,type:'Troop',rarity:'Epic',arena:10,description:'Slow durable building-targeter.',id:26000009},
  {key:'skeletons',name:'Skeletons',elixir:1,type:'Troop',rarity:'Common',arena:2,description:'Cheap melee swarm.',id:26000010},
  {key:'valkyrie',name:'Valkyrie',elixir:4,type:'Troop',rarity:'Rare',arena:2,description:'Tough area-damage melee fighter.',id:26000011},
  {key:'bomber',name:'Bomber',elixir:2,type:'Troop',rarity:'Common',arena:2,description:'Cheap ranged area damage.',id:26000013},
  {key:'musketeer',name:'Musketeer',elixir:4,type:'Troop',rarity:'Rare',arena:0,description:'Long-range single-target attacker.',id:26000014},
  {key:'baby-dragon',name:'Baby Dragon',elixir:4,type:'Troop',rarity:'Epic',arena:6,description:'Flying area damage.',id:26000015},
  {key:'prince',name:'Prince',elixir:5,type:'Troop',rarity:'Epic',arena:7,description:'Charge melee attacker.',id:26000016},
  {key:'wizard',name:'Wizard',elixir:5,type:'Troop',rarity:'Rare',arena:4,description:'Long-range area damage.',id:26000017},
  {key:'mini-pekka',name:'Mini P.E.K.K.A',elixir:4,type:'Troop',rarity:'Rare',arena:0,description:'High single-target melee damage.',id:26000018},
  {key:'spear-goblins',name:'Spear Goblins',elixir:2,type:'Troop',rarity:'Common',arena:1,description:'Cheap ranged trio.',id:26000019},
  {key:'giant-skeleton',name:'Giant Skeleton',elixir:6,type:'Troop',rarity:'Epic',arena:8,description:'Heavy troop with death bomb.',id:26000020},
  {key:'hog-rider',name:'Hog Rider',elixir:4,type:'Troop',rarity:'Rare',arena:5,description:'Fast building-targeter.',id:26000021},
  {key:'minion-horde',name:'Minion Horde',elixir:5,type:'Troop',rarity:'Common',arena:10,description:'Six flying attackers.',id:26000022},
  {key:'ice-wizard',name:'Ice Wizard',elixir:3,type:'Troop',rarity:'Legendary',arena:12,description:'Ranged slow support.',id:26000023},
  {key:'royal-giant',name:'Royal Giant',elixir:6,type:'Troop',rarity:'Common',arena:7,description:'Ranged building-targeting win condition.',id:26000024},
  {key:'guards',name:'Guards',elixir:3,type:'Troop',rarity:'Epic',arena:6,description:'Shielded swarm.',id:26000025},
  {key:'princess',name:'Princess',elixir:3,type:'Troop',rarity:'Legendary',arena:11,description:'Long-range splash attacker.',id:26000026},
  {key:'dark-prince',name:'Dark Prince',elixir:4,type:'Troop',rarity:'Epic',arena:7,description:'Shielded charge splash attacker.',id:26000027},
  {key:'three-musketeers',name:'Three Musketeers',elixir:9,type:'Troop',rarity:'Rare',arena:7,description:'Three ranged attackers.',id:26000028},
  {key:'lava-hound',name:'Lava Hound',elixir:7,type:'Troop',rarity:'Legendary',arena:13,description:'Flying tank that targets buildings.',id:26000029},
  {key:'ice-spirit',name:'Ice Spirit',elixir:1,type:'Troop',rarity:'Common',arena:8,description:'Cheap freeze jump.',id:26000030},
  {key:'fire-spirit',name:'Fire Spirit',elixir:1,type:'Troop',rarity:'Common',arena:4,description:'Jumping area damage.',id:26000031},
  {key:'miner',name:'Miner',elixir:3,type:'Troop',rarity:'Legendary',arena:11,description:'Burrows anywhere and targets troops/buildings.',id:26000032},
  {key:'sparky',name:'Sparky',elixir:6,type:'Troop',rarity:'Legendary',arena:11,description:'Charging area damage.',id:26000033},
  {key:'bowler',name:'Bowler',elixir:5,type:'Troop',rarity:'Epic',arena:13,description:'Rolling splash attack.',id:26000034},
  {key:'lumberjack',name:'Lumberjack',elixir:4,type:'Troop',rarity:'Legendary',arena:14,description:'Fast attacker with death Rage.',id:26000035},
  {key:'battle-ram',name:'Battle Ram',elixir:4,type:'Troop',rarity:'Rare',arena:3,description:'Charging building attacker.',id:26000036},
  {key:'fireball',name:'Fireball',elixir:4,type:'Spell',rarity:'Rare',arena:0,description:'Area damage spell.',id:28000000},
  {key:'arrows',name:'Arrows',elixir:3,type:'Spell',rarity:'Common',arena:0,description:'Large area damage spell.',id:28000001},
  {key:'rage',name:'Rage',elixir:2,type:'Spell',rarity:'Epic',arena:14,description:'Boosts attack and movement speed.',id:28000002},
  {key:'rocket',name:'Rocket',elixir:6,type:'Spell',rarity:'Rare',arena:5,description:'High damage spell.',id:28000003},
  {key:'goblin-barrel',name:'Goblin Barrel',elixir:3,type:'Spell',rarity:'Epic',arena:6,description:'Spawns Goblins anywhere.',id:28000004},
  {key:'freeze',name:'Freeze',elixir:4,type:'Spell',rarity:'Epic',arena:8,description:'Freezes and damages enemies.',id:28000005},
  {key:'lightning',name:'Lightning',elixir:6,type:'Spell',rarity:'Epic',arena:8,description:'Damages and stuns up to three targets.',id:28000007},
  {key:'zap',name:'Zap',elixir:2,type:'Spell',rarity:'Common',arena:5,description:'Small area damage and stun.',id:28000008}
];

export function assetUrl(key, variant='base') {
  const suffix = variant === 'base' ? '' : `-${variant}`;
  return `${SOURCES.assets}${key}${suffix}.png`;
}

function normalizeStatRecord(rec) {
  if (!rec || typeof rec !== 'object') return null;
  const key = rec.key || rec.sc_key || rec.name?.toLowerCase()?.replaceAll(' ', '-') || null;
  return { ...rec, _matchKey:key };
}

function buildStatIndex(statArrays) {
  const idx = new Map();
  for (const arr of statArrays) {
    if (!Array.isArray(arr)) continue;
    for (const raw of arr) {
      const rec = normalizeStatRecord(raw);
      if (!rec) continue;
      const keys = [rec._matchKey, rec.key, rec.sc_key, rec.name].filter(Boolean).map(String);
      for (const k of keys) {
        const list = idx.get(k) || [];
        list.push(rec);
        idx.set(k, list);
      }
    }
  }
  return idx;
}

function chooseStats(card, idx) {
  const candidates = [card.key, card.sc_key, card.name].filter(Boolean);
  for (const k of candidates) {
    const list = idx.get(String(k));
    if (list?.length) {
      const base = list.find(x => x.is_evolved === false) || list[0];
      return base;
    }
  }
  return null;
}

function pickLevel(arr, level) {
  if (!Array.isArray(arr) || !arr.length) return null;
  const i = Math.max(0, Math.min(arr.length - 1, level - 1));
  return arr[i];
}

export function enrichCards(cards, statArrays, level=11) {
  const idx = buildStatIndex(statArrays);
  return cards.map(card => {
    const stats = chooseStats(card, idx);
    const hitpoints = pickLevel(stats?.hitpoints_per_level, level) ?? stats?.hitpoints ?? null;
    const damage = pickLevel(stats?.damage_per_level, level) ?? stats?.damage ?? null;
    const dps = pickLevel(stats?.dps_per_level, level) ?? stats?.dps ?? (damage && stats?.hit_speed ? damage / (stats.hit_speed/1000) : null);
    return {
      ...card,
      stats: stats ? {
        level,
        hp: hitpoints,
        damage,
        dps,
        hitSpeedMs: stats.hit_speed ?? null,
        range: stats.range ?? null,
        sightRange: stats.sight_range ?? null,
        speed: stats.speed ?? null,
        deployTime: stats.deploy_time ?? null,
        attacksGround: stats.attacks_ground ?? null,
        attacksAir: stats.attacks_air ?? null,
        targetOnlyBuildings: stats.target_only_buildings ?? false,
        areaRadius: stats.area_damage_radius ?? 0,
        deathDamage: stats.death_damage ?? 0,
        deathRadius: stats.death_damage_radius ?? 0,
        lifetimeMs: stats.life_time ?? 0,
        projectile: stats.projectile ?? null,
        spawnCharacter: stats.spawn_character ?? null,
        spawnNumber: stats.spawn_number ?? 0,
        spawnInterval: stats.spawn_interval ?? 0,
        ability: stats.ability ?? null,
        shieldHp: stats.shield_hitpoints ?? 0,
        dashDamage: stats.dash_damage ?? 0,
        chargeRange: stats.charge_range ?? 0,
        raw: stats
      } : null,
      image: assetUrl(card.key)
    };
  });
}

export async function loadDatabase({level=11}={}) {
  const cached = localStorage.getItem('clash-trainer-db-v1');
  let base = null;
  if (cached) {
    try { base = JSON.parse(cached); } catch {}
  }
  const fetchJSON = async (url) => {
    const res = await fetch(url, {cache:'no-store'});
    if (!res.ok) throw new Error(`${res.status} ${url}`);
    return res.json();
  };
  try {
    let cards; let stats;
    try {
      cards = await fetchJSON('./data/cards.json');
      stats = await Promise.all(['./data/cards_stats_troop.json','./data/cards_stats_building.json','./data/cards_stats_spell.json','./data/cards_stats_characters.json','./data/cards_stats_projectile.json','./data/cards_evo.json'].map(fetchJSON));
    } catch {
      [cards, ...stats] = await Promise.all([fetchJSON(SOURCES.cards), ...SOURCES.stats.map(fetchJSON)]);
    }
    const enriched = enrichCards(cards, stats, level);
    const db = {version: new Date().toISOString().slice(0,10), cards:enriched};
    localStorage.setItem('clash-trainer-db-v1', JSON.stringify(db));
    return {db, online:true};
  } catch (e) {
    if (base?.cards?.length) {
      return {db:base, online:false, error:e};
    }
    return {db:{version:'fallback',cards:enrichCards(FALLBACK_CARDS,[],level)},online:false,error:e};
  }
}
