import fs from 'node:fs/promises';
const cards=JSON.parse(await fs.readFile(new URL('../data/cards.json',import.meta.url),'utf8'));
const base=cards.filter(c=>!c.is_evolved);
const ids=new Set(cards.map(c=>c.id));
const keys=new Set(cards.map(c=>c.key));
const problems=[];
for(const c of base){
  if(!c.key||!c.name||!Number.isInteger(c.id))problems.push(`${c.key||'?'} identity`);
  if(!['Troop','Building','Spell'].includes(c.type))problems.push(`${c.key} type=${c.type}`);
  if(typeof c.elixir!=='number')problems.push(`${c.key} elixir`);
  if(!c.rarity)problems.push(`${c.key} rarity`);
  if(!Number.isInteger(c.arena))problems.push(`${c.key} arena`);
}
console.log(JSON.stringify({totalRecords:cards.length,baseCards:base.length,uniqueIds:ids.size,uniqueKeys:keys.size,problems},null,2));
if(problems.length)process.exitCode=1;
