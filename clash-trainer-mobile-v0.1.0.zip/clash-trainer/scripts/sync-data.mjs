import fs from 'node:fs/promises';
import path from 'node:path';
const root=path.resolve(new URL('..',import.meta.url).pathname);
const base='https://raw.githubusercontent.com/RoyaleAPI/cr-api-data/master/docs/json/';
const files=['cards.json','cards_stats_troop.json','cards_stats_building.json','cards_stats_spell.json','cards_stats_characters.json','cards_stats_projectile.json','cards_evo.json'];
const out=path.join(root,'data');
await fs.mkdir(out,{recursive:true});
for(const f of files){const r=await fetch(base+f);if(!r.ok)throw new Error(`${f}: ${r.status}`);await fs.writeFile(path.join(out,f),await r.text());}
console.log(`Synced ${files.length} JSON files to ${out}`);
