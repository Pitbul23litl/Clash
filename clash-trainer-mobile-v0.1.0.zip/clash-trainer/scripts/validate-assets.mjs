import fs from 'node:fs/promises';
const cards=JSON.parse(await fs.readFile(new URL('../data/cards.json',import.meta.url),'utf8')).filter(c=>!c.is_evolved);
const base='https://raw.githubusercontent.com/RoyaleAPI/cr-api-assets/master/cards/';
let miss=0, ok=0;
for(const c of cards){const url=base+c.key+'.png';const r=await fetch(url);if(r.ok){ok++;}else{miss++;console.log(`MISSING ${c.key} -> ${r.status}`)}}
console.log(`Checked ${cards.length}: ok=${ok}, missing=${miss}`);
if(miss) process.exitCode=1;
