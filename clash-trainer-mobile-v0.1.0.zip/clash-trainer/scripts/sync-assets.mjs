import fs from 'node:fs/promises';
import path from 'node:path';
const root=path.resolve(new URL('..',import.meta.url).pathname);
const cards=JSON.parse(await fs.readFile(path.join(root,'data/cards.json'),'utf8'));
const out=path.join(root,'assets/cards'); await fs.mkdir(out,{recursive:true});
const base='https://raw.githubusercontent.com/RoyaleAPI/cr-api-assets/master/cards/';
const selected=[...new Map(cards.map(c=>[c.key,c])).values()];
const report=[];
for(const c of selected){
  const url=base+c.key+'.png';
  try{const r=await fetch(url); if(!r.ok){report.push({key:c.key,status:r.status});continue;} await fs.writeFile(path.join(out,c.key+'.png'),Buffer.from(await r.arrayBuffer()));report.push({key:c.key,status:200});}
  catch(e){report.push({key:c.key,status:'error',error:String(e)})}
}
await fs.writeFile(path.join(root,'data/assets-manifest.json'),JSON.stringify({checked:new Date().toISOString(),items:report},null,2));
console.log(`Assets checked: ${selected.length}; downloaded: ${report.filter(x=>x.status===200).length}; missing/error: ${report.filter(x=>x.status!==200).length}`);
