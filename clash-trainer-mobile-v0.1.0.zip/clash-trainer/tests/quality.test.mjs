import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { SCENARIOS } from '../src/scenarios.js';

test('scenario library has dozens of distinct exercises',()=>{assert.ok(SCENARIOS.length>=36);assert.equal(new Set(SCENARIOS.map(s=>s.id)).size,SCENARIOS.length)});
test('schemas exist',()=>{assert.ok(fs.existsSync('schemas/card.schema.json'));assert.ok(fs.existsSync('schemas/battle.schema.json'))});
