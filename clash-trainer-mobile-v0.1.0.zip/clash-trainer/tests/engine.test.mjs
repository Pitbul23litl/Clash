import test from 'node:test';
import assert from 'node:assert/strict';
import {elixirRate,tickElixir,averageElixir,makeInitialState,playCard,chooseBotDeck,phaseForTime} from '../src/engine.js';
const c=(key,elixir,type='Troop')=>({key,name:key,elixir,type,stats:{hp:1000,damage:100,hit_speed:1000,dps:100}});

test('elixir rate switches at double elixir',()=>{assert.equal(elixirRate(119),1);assert.equal(elixirRate(120),2);assert.equal(Math.round(tickElixir(0,2.8,0)),1);assert.equal(Math.round(tickElixir(0,2.8,120)),2)});
test('average elixir',()=>{assert.equal(averageElixir([c('a',1),c('b',5)]),3)});
test('initial state has 5 elixir and 4 card hand',()=>{const s=makeInitialState([c('a',3),c('b',4),c('c',2),c('d',1),c('e',5),c('f',2),c('g',3),c('h',4)],[c('x',3),c('y',4),c('z',2),c('q',1),c('w',5),c('r',2),c('t',3),c('u',4)]);assert.equal(s.players.player.elixir,5);assert.equal(s.players.player.hand.length,4)});
test('play card consumes elixir and rotates hand',()=>{const d=[c('a',3),c('b',4),c('c',2),c('d',1),c('e',5),c('f',2),c('g',3),c('h',4)];const s=makeInitialState(d,d);const r=playCard(s,'player','a',{x:.5,y:.7});assert.equal(r.ok,true);assert.equal(s.players.player.elixir,2);assert.equal(s.players.player.hand.some(x=>x.key==='e'),true)});
test('bot deck is 8 unique cards',()=>{const p=[c('w1',4),c('s1',3,'Spell'),c('m1',3),c('b1',4),c('r1',4),c('sw1',2),c('g1',5),c('r2',4)];const pool=[...Array(20)].map((_,i)=>c('k'+i,(i%6)+1));const d=chooseBotDeck(pool,p,42);assert.equal(d.length,8);assert.equal(new Set(d.map(x=>x.key)).size,8)});
test('phase switch',()=>{assert.equal(phaseForTime(10),'single');assert.equal(phaseForTime(120),'double')});
